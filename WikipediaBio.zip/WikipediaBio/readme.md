# Wikipedia Self Bio Webpage
Cameron Reifinger   
February 14, 2023

![Screenshot](Screenshot.png "Screenshot")

[GitHub Link](https://github.com/MrCameron2256/Wiki-Page)

